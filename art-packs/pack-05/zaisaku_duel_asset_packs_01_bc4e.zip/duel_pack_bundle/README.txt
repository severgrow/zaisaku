ZAISAKU Duel Asset Pack Bundle

Contents:
- pack05_duel_ui_set_a.png : first duel UI asset sheet
- pack05_duel_ui_set_b.png : second duel UI asset sheet

Style:
Mineral Analog / bone ceramic / green-grey alloy / amber glow / muted burgundy

Suggested use:
- empty UI frames and containers
- duel tables and exchange consoles
- trays, slots, shelves, counters
- dials, levers, sliders, timers
- display frames, portrait frames, result panels
- resonance effects and status indicators

These are source sheets for Cursor to crop and integrate.
