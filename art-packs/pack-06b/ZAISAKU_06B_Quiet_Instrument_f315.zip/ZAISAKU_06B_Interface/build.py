from pathlib import Path
import json
p=Path(__file__).parent
icons={
'home':'<path d="M5 11 12 5l7 6v8H5zM10 19v-6h4v6"/>',
'world':'<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c-5 5-5 11 0 16 5-5 5-11 0-16"/>',
'duel':'<path d="M4 8h13l-3-3m3 3-3 3M20 16H7l3 3m-3-3 3-3"/><circle cx="5" cy="16" r="1"/><circle cx="19" cy="8" r="1"/>',
'market':'<path d="M4 10h16l-2-5H6zM6 10v9h12v-9M9 19v-5h6v5"/>',
'auction':'<path d="m6 5 5 5-3 3-5-5zM11 10l8 8M14 20h7M13 18h7"/>',
'vault':'<rect x="4" y="5" width="16" height="14" rx="3"/><circle cx="12" cy="12" r="3"/><path d="M12 9v6M9 12h6"/>',
'requests':'<rect x="6" y="4" width="12" height="16" rx="2"/><path d="M9 8h6M9 12h6M9 16h3"/>',
'results':'<path d="M5 19V5M5 19h14M9 15v-4M13 15V7M17 15V9"/>',
'settings':'<path d="M5 7h14M5 12h14M5 17h14"/><circle cx="9" cy="7" r="2" fill="currentColor"/><circle cx="15" cy="12" r="2" fill="currentColor"/><circle cx="10" cy="17" r="2" fill="currentColor"/>',
'back':'<path d="m14 5-7 7 7 7M7 12h13"/>','close':'<path d="m6 6 12 12M18 6 6 18"/>','plus':'<path d="M12 5v14M5 12h14"/>','minus':'<path d="M5 12h14"/>','check':'<path d="m5 12 4 4 10-9"/>','warning':'<path d="m12 4 9 16H3zM12 9v5M12 17h.01"/>','info':'<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8h.01"/>','lock':'<rect x="6" y="10" width="12" height="10" rx="2"/><path d="M9 10V7a3 3 0 0 1 6 0v3"/>','inspect':'<circle cx="10" cy="10" r="5"/><path d="m14 14 6 6"/>','interact':'<path d="M8 12V6a2 2 0 0 1 4 0v5h5a2 2 0 0 1 2 2l-2 7H9l-5-7a2 2 0 0 1 3-2z"/>','talk':'<path d="M4 5h16v11h-8l-5 4v-4H4zM8 10h.01M12 10h.01M16 10h.01"/>','wire':'<circle cx="12" cy="12" r="2"/><path d="M12 14v6M7 7a7 7 0 0 0 0 10M17 7a7 7 0 0 1 0 10M4 4a11 11 0 0 0 0 16M20 4a11 11 0 0 1 0 16"/>','resonance':'<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="7"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>','chevron-right':'<path d="m9 5 7 7-7 7"/>','chevron-down':'<path d="m5 9 7 7 7-7"/>','sound':'<path d="M4 10h4l5-5v14l-5-5H4zM16 8a6 6 0 0 1 0 8M19 5a10 10 0 0 1 0 14"/>','expand':'<path d="M9 4H4v5M15 4h5v5M4 15v5h5M20 15v5h-5"/>','currency':'<path d="M6 5h12L6 19h12M5 10h14M5 14h14"/>'}
for n,b in icons.items(): (p/'icons'/f'{n}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{b}</svg>')
(p/'manifest.json').write_text(json.dumps({'pack':'06B','status':'candidate','supersedes':'06 interface only','icons':list(icons),'textBakedIntoAssets':False,'integration':'opt-in .za-ui scope; map existing controls; preserve semantics'},indent=2))
