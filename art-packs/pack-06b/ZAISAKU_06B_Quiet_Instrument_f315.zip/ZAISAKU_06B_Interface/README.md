# ZAISAKU 06B — Quiet Instrument
Replacement for the previous pixel-art menu pack. Keep all world sprites and Pack 05 duel machinery. This is an opt-in CSS/SVG candidate skin, not an integrated game patch.

Use tokens.css and components.css; attach `.za-ui` to the application root. Map existing shell, buttons, dialogs, inventory, HUD, inputs and meters to these classes without replacing their behaviour. SVG icons use currentColor and can be inlined or used as masks (`--za-icon: url(...)`). Keep icon labels in accessible HTML, never in artwork. Use current project fonts or any chosen font via `--za-font` and `--za-number-font`. All labels, numbers, translations remain live. Currency icon is a candidate only; retain existing currency notation unless approved.

Use quiet surfaces for most menus, ceramic primary controls, amber for selection, burgundy for destructive actions. No gold borders, decorative panels around every row or new pixel typography. Do not apply this skin to the physical duel instrument indiscriminately.

Verify actual game screenshots and accessibility, including focus, reduced motion, large text, mobile orientation, Polish labels and long translations. Do not reset saves or change mechanics. No direct game integration or browser testing performed for this pack. Upload unchanged to art/mineral-analog-packs with SHA-256. Retire old Pack 06 UI assets only after approval.
