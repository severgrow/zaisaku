# ZAISAKU Pack 08B — strict runtime subset
Supersedes Pack 08 for runtime delivery. Only standalone props and UI sprites with checked PNG dimensions, transparency, anchors and crop components are included. No concept sheets or character pose references. Contact shadow uses intentional soft alpha; resonance is an independent ground decal. All other sprites use binary alpha and nearest-neighbour scaling. Ground overlays and UI art are centre anchored; world props are bottom-centre anchored. These are file-validated, NOT Phaser-tested or production approved. Keep temporary status until tested.

Vault door is a closed visual overlay for a south-facing opening; do not replace collision or assume other orientations. Tree and plant have overhang; use logical footprints separately. Do not stretch artwork or apply automatic collision from image bounds. Use existing renderer's 2:1 source/logical ratio as a starting point, then confirm placement.

Withheld: all five building facades (actual doorway alignment/orientation not verified), district gate (map edge alignment not verified), foundation course (not seamless), 16 character poses (identity mismatch), Vesper portrait (identity unapproved). Do not import these from Pack 08. The remaining requested assets require a separate approved redraw and integration test.

Stage ZIP unchanged on art/mineral-analog-packs; record checksum. No gameplay changes.
