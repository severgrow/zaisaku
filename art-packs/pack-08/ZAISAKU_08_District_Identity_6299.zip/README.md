# ZAISAKU Pack 08 — District Identity

Contains two original generated sheets, individually cropped runtime candidates, 16 pose references, manifest and preview. All labels are runtime text. The facade artwork is south-facing; the existing east/west entries need separate directional adaptation, not arbitrary rotation. Do not replace modular wall/roof collision or geometry with a picture. Foundation step is a decorative reference, not a validated seamless course. Generated character identities differ from Pack 02: pose references ONLY; use approved Pack 02 bases to create actual use/idle variants. Vesper portrait is provisional. The generated resonance mark may need alpha refinement; do not bake effects into terrain. No Phaser testing has been performed. Preserve existing Pack 02–07 assets and gameplay.

Stage this archive unchanged on art/mineral-analog-packs, record SHA-256, then import only reviewed runtime assets. Keep sources and pose references outside the production bundle.
