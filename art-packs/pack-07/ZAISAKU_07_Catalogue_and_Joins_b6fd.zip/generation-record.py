from PIL import Image, ImageDraw, ImageFont
import numpy as np, scipy.ndimage as nd, zipfile, io, json, shutil, pathlib, hashlib
P=pathlib.Path('/mnt/data/ZAISAKU_Pack_07'); P.mkdir(exist_ok=True)
z=zipfile.ZipFile('/mnt/data/ZAISAKU_04_Runtime.zip'); records=[]; checks=[]
def read(p):return Image.open(io.BytesIO(z.read('runtime/'+p+'.png'))).convert('RGBA')
def save(im,p,**kw):
 f=P/p;f.parent.mkdir(parents=True,exist_ok=True); im.save(f); records.append(dict(file=p,width=im.width,height=im.height,**kw));return im
def check(n,v):checks.append({'check':n,'pass':bool(v)})
ids='tomorrow-receiver dream-receiver null-magnet silent-telephone wire-hymnal pocket-static red-coil moon-clock amber-hourglass saltwater-watch memory-lens dust-telescope catalogue-eye orchid-vessel kiln-ghost tea-for-nobody white-jar red-box glass-saint mute-candle'.split()
src=pathlib.Path('/mnt/data/a_clean_transparent_background_pixel_art_spriteshe.png'); im=Image.open(src).convert('RGBA'); W,H=im.size
for i,id in enumerate(ids):
 c,r=i%5,i//5; a=np.array(im.crop((round(c*W/5),round(r*H/4),round((c+1)*W/5),round((r+1)*H/4)))); m=a[:,:,3]>=160; lab,_=nd.label(m); counts=np.bincount(lab.ravel()); counts[0]=0; keep=counts>=max(20,counts.max()*.015);keep[0]=False;m=keep[lab];a[~m]=0;a[m,3]=255; v=Image.fromarray(a);v=v.crop(v.getbbox());s=min(116/v.width,116/v.height);v=v.resize((round(v.width*s),round(v.height*s)),Image.Resampling.NEAREST);o=Image.new('RGBA',(128,128));o.alpha_composite(v,((128-v.width)//2,(128-v.height)//2));save(o,'runtime/catalogue/item-'+id+'.png',kind='catalogue',definitionId=id,pixelKey='item-'+id,status='candidate');save(o.resize((64,64),Image.Resampling.NEAREST),'runtime/catalogue64/item-'+id+'.png',kind='catalogue-fallback',definitionId=id,status='candidate');check(id+' alpha and padding',o.getbbox()[0]>=5 and o.getbbox()[1]>=5 and o.getbbox()[2]<=123 and o.getbbox()[3]<=123)
# Match the exact material edge profiles of Pack 04. Union for convex A corner; intersection for concave notch.
A=np.array(read('floors/floor-bone-ceramic')); yy,xx=np.mgrid[:64,:64]; dist={'n':yy,'e':63-xx,'s':63-yy,'w':xx};
for material in ['mineral-paving','resonance-path']:
 B=np.array(read('floors/floor-'+material)); weights={}
 for d in 'nesw':
  t=xx if d in 'ns' else yy; line=31.5+np.round(2*np.sin(t*2*np.pi/63)+1.3*np.sin(t*6*np.pi/63));weights[d]=np.clip((line-dist[d]+2)/4,0,1)
 def blend(w):return np.round(A*(1-w[...,None])+B*w[...,None]).astype(np.uint8)
 straights={d:blend(weights[d]) for d in 'nesw'}
 if material=='resonance-path':
  for d,v in straights.items():save(Image.fromarray(v),f'runtime/transitions/bone-ceramic-to-{material}-{d}.png',kind='transition',fromMaterial='bone-ceramic',toMaterial=material,neighborSide=d,logicalTile=32)
 else:
  for d,v in straights.items():check('existing straight matches '+d,np.array_equal(v,np.array(read('transitions/bone-ceramic-to-mineral-paving-'+d))))
 edges={'n':lambda a:a[0], 's':lambda a:a[-1], 'w':lambda a:a[:,0], 'e':lambda a:a[:,-1]};opp=dict(n='s',s='n',w='e',e='w')
 for pair in ['ne','es','sw','wn']:
  for form,fn in [('outer',np.maximum),('inner',np.minimum)]:
   v=blend(fn(weights[pair[0]],weights[pair[1]]));save(Image.fromarray(v),f'runtime/transitions/bone-ceramic-to-{material}-{form}-{pair}.png',kind='transition-corner',fromMaterial='bone-ceramic',toMaterial=material,corner=form,sides=pair,logicalTile=32)
   for d in 'nesw':
    other=pair[1] if d==pair[0] else pair[0] if d==pair[1] else next(k for k in pair if k!=opp[d]); target=(B if d in pair else straights[other]) if form=='outer' else (straights[other] if d in pair else A);check(f'{material} {form} {pair} edge {d}',np.array_equal(edges[d](v),edges[opp[d]](target)))
# side-facing opening using exact old vertical wall edge strips, separately draw east/west trim; no opaque fill in aperture.
wall=read('architecture/wall-straight-ns'); ar=np.array(wall)
for face in 'ew':
 for kind in ['door','window']:
  v=wall.copy();d=ImageDraw.Draw(v); x0,x1=(24,39); d.rectangle((x0,19,x1,46),fill=(0,0,0,0));
  if kind=='door':
   d.rectangle((24,17,39,23),fill='#c9b59a');d.line((24,17,39,17),fill='#e6d7c3',width=2);d.rectangle((24,23,27,30),fill='#8d7b68');d.rectangle((36,40,39,47),fill='#4c5340');d.rectangle(((37 if face=='e' else 24),24,(39 if face=='e' else 26),28),fill='#d29a3a')
  else:
   d.rectangle((24,18,39,22),fill='#c9b59a');d.rectangle((24,42,39,47),fill='#8d7b68');d.rectangle((24 if face=='e' else 37,23,26 if face=='e' else 39,41),fill='#6d7550');d.line((27,22,36,22),fill='#e6d7c3')
  a=np.array(v);a[:4]=ar[:4];a[-4:]=ar[-4:];save(Image.fromarray(a),f'runtime/architecture/{kind}-frame-open-{face}.png',kind='wall-opening',facing=face,connections='ns',anchor=[32,64],logicalTile=32);check(kind+face+' connectors',np.array_equal(a[0],ar[0]) and np.array_equal(a[-1],ar[-1]));check(kind+face+' opening',a[32,32,3]==0)
# roof extension is separate new family. All horizontal edges match within this family. Lower lip meets wall via optional upper-wall bridge.
roof=np.array(read('architecture/roof-straight-ew'));v=roof.copy();v[53:64]=roof[43:54];v[62:64,:, :3]=[76,83,64];v[62:64,:,3]=255;v[:,-1]=v[:,0];save(Image.fromarray(v),'runtime/architecture/roof-straight-ew-bottom.png',kind='roof-extended',connections='ew',anchor=[32,64],logicalTile=32,requires='wall-straight-ew-top-bridge');check('roof bottom full',np.all(v[-1,:,3]==255));check('roof horizontal repeat',np.array_equal(v[:,0],v[:,-1])); wh=np.array(read('architecture/wall-straight-ew')); bridge=wh.copy();bridge[:16]=wh[16:32];bridge[0]=v[-1];bridge[:,-1]=bridge[:,0];save(Image.fromarray(bridge),'runtime/architecture/wall-straight-ew-top-bridge.png',kind='wall-bridge',connections='ew',logicalTile=32,anchor=[32,64]);check('roof wall bridge exact',np.array_equal(bridge[0],v[-1]));
# clear case: use original base, construct empty glass rails in separate foreground, no opacity over item aperture
case=read('furniture/furniture-glass-display'); ca=np.array(case); base=Image.new('RGBA',(128,128));base.paste(case.crop((0,88,128,128)),(0,88));d=ImageDraw.Draw(base);d.polygon([(28,88),(100,88),(109,97),(19,97)],fill='#c9b59a');d.line((28,88,100,88),fill='#e6d7c3',width=2);save(base,'runtime/furniture/glass-case-base.png',kind='furniture-layer',layer='back',anchor=[64,128],itemAnchor=[64,92]);front=Image.new('RGBA',(128,128));d=ImageDraw.Draw(front);d.line([(25,92),(25,34),(37,19),(91,19),(103,34),(103,92)],fill='#8d9584',width=3);d.line([(29,34),(99,34)],fill='#e6d7c3',width=2);d.line([(37,20),(29,34),(29,89)],fill='#d7d8c2',width=2);d.line([(91,20),(99,34),(99,89)],fill='#a2ad9b',width=2);save(front,'runtime/furniture/glass-case-front.png',kind='furniture-layer',layer='front',anchor=[64,128],itemAnchor=[64,92]);check('glass front clear center',np.all(np.array(front)[38:87,34:94,3]==0));check('glass base clear center',np.all(np.array(base)[38:87,34:94,3]==0));
# North-facing canopy: roof only, no posts and no overlap into doorway cell, tile north of door.
aw=Image.new('RGBA',(64,64));d=ImageDraw.Draw(aw);d.polygon([(8,10),(55,10),(61,16),(61,32),(3,32),(3,16)],fill='#4c5340');d.rectangle((7,13,57,27),fill='#c9b59a');
for i in range(5):d.rectangle((8+i*10,14,16+i*10,26),fill='#8d5550' if i%2==0 else '#e6d7c3')
d.rectangle((4,28,60,32),fill='#8d7b68');d.line((8,12,55,12),fill='#e6d7c3',width=2);save(aw,'runtime/architecture/awning-north-door.png',kind='awning',facing='n',placement='one cell north of door; canopy-only; no posts',anchor=[32,64],logicalTile=32);check('awning lower half clear',np.all(np.array(aw)[33:,:,3]==0))
# Preview actual runtime assets
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
def preview(paths,name,cols=5,sz=160):
 out=Image.new('RGB',(cols*sz,((len(paths)+cols-1)//cols)*sz),'#262b26');d=ImageDraw.Draw(out)
 for i,p in enumerate(paths):
  v=Image.open(P/p);v.thumbnail((sz-12,sz-36),Image.Resampling.NEAREST);x=i%cols*sz;y=i//cols*sz;out.paste(v,(x+(sz-v.width)//2,y+4),v); label=pathlib.Path(p).stem.replace('item-','').replace('bone-ceramic-to-','');d.text((x+5,y+sz-28),label,font=font,fill='#ded4bf')
 (P/'previews').mkdir(exist_ok=True);out.save(P/'previews'/name)
preview([r['file'] for r in records if r['kind']=='catalogue'],'catalogue.png');preview([r['file'] for r in records if r['kind'] not in ['catalogue','catalogue-fallback']],'technical.png',4,220)
for r in records:
 f=P/r['file']; check(r['file']+' dimensions',Image.open(f).size==(r['width'],r['height']));r['sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'manifest.json').write_text(json.dumps({'pack':'07','status':'candidate','logicalTileSize':32,'textureFilter':'nearest','runtimeAssets':records},indent=2));(P/'validation.json').write_text(json.dumps({'passed':sum(c['pass'] for c in checks),'total':len(checks),'checks':checks},indent=2));(P/'sources').mkdir(exist_ok=True);shutil.copy2(src,P/'sources/catalogue-original.png');
(P/'README.md').write_text('''# ZAISAKU Pack 07 — catalogue completion and District joins\nCandidate artwork. All 20 catalogue IDs supplied at 128 and 64px. Original generated sheet included. Technical art constructed from Pack 04 pixels, not generated floor icons.\n\nTransition corners: outer = union of two B-facing side masks; inner = intersection. Pair letters are adjacent B-facing edges for outer, adjacent mixed edges for inner. Straight ceramic-to-resonance-path tiles supplied too. Use metadata and validation, test actual map topology.\nEast/west openings connect to N/S vertical walls; both are transparent apertures with different trim, not rotated south sprites. Roof bottom variant requires the matching top-bridge wall variant directly below; use together in a full horizontal run and do not mix with old roof edge profiles without testing ends. North awning is canopy-only; place one tile north of door and do not draw on door cell. Glass case uses base then actual item at [64,92] then front glass rails; no opaque interior.\n\nKeep all Pack 02 animations and Pack 04 plates, soil, metal and rails. Catalogue art is candidate until visual approval. The pack is pixel-validated, not tested in Phaser. Do not change rules, collision or persistence. Upload unchanged ZIP to art/mineral-analog-packs and record SHA-256.\n''')
shutil.copy2('/tmp/pack07.py',P/'generation-record.py')
with zipfile.ZipFile('/mnt/data/ZAISAKU_07_Catalogue_and_Joins.zip','w',zipfile.ZIP_DEFLATED) as out:
 for f in sorted(P.rglob('*')):
  if f.is_file():out.write(f,f.relative_to(P))
print(len(records),sum(c['pass'] for c in checks),len(checks),[c['check'] for c in checks if not c['pass']]);print(pathlib.Path('/mnt/data/ZAISAKU_07_Catalogue_and_Joins.zip').stat().st_size)
