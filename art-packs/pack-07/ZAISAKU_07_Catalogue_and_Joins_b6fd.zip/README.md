# ZAISAKU Pack 07 — catalogue completion and District joins
Candidate artwork. All 20 catalogue IDs supplied at 128 and 64px. Original generated sheet included. Technical art constructed from Pack 04 pixels, not generated floor icons.

Transition corners: outer = union of two B-facing side masks; inner = intersection. Pair letters are adjacent B-facing edges for outer, adjacent mixed edges for inner. Straight ceramic-to-resonance-path tiles supplied too. Use metadata and validation, test actual map topology.
East/west openings connect to N/S vertical walls; both are transparent apertures with different trim, not rotated south sprites. Roof bottom variant requires the matching top-bridge wall variant directly below; use together in a full horizontal run and do not mix with old roof edge profiles without testing ends. North awning is canopy-only; place one tile north of door and do not draw on door cell. Glass case uses base then actual item at [64,92] then front glass rails; no opaque interior.

Keep all Pack 02 animations and Pack 04 plates, soil, metal and rails. Catalogue art is candidate until visual approval. The pack is pixel-validated, not tested in Phaser. Do not change rules, collision or persistence. Upload unchanged ZIP to art/mineral-analog-packs and record SHA-256.
