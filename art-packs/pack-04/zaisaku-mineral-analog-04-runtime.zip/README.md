# ZAISAKU / Mineral Analog / Asset Pack 04

This corrective pack responds to the integration review of Packs 02 and 03. It is **not** another collection of isolated floor or wall icons. Technical environment tiles have been drawn on a native pixel grid; the new catalogue and empty furniture use generated illustrated artwork. All files are candidate assets until the creator approves actual gameplay.

## Start here

- `runtime/floors/`: six opaque, edge-to-edge 64 × 64 textures. Each has identical left/right and top/bottom RGBA edges. No symbols, lamps, decorative frames, or transparent margins.
- `runtime/transitions/`: eight 64 × 64 directional transitions. The named direction is the edge that touches the second material; the opposite edge touches the first. Perpendicular edges match each other. For example, `bone-ceramic-to-mineral-paving-n.png` has mineral paving at its north edge and bone ceramic at its south edge. These are straight boundary transitions, not a complete corner/autotile set for arbitrary curved terrain.
- `runtime/architecture/`: 64 × 64 connected wall, roof and railing sprites, including oriented inner/outer corners, straight runs, T junctions, end caps and wall cross; horizontal open door and window frames. Their actual open space is transparent. The door and window match the horizontal wall connector. These are projected top-down modules rather than rotated front-facing icons. Inner/outer variants use different bend geometry but identical connectors.
- `runtime/furniture/`: three empty display pieces, each supplied at 128 × 128 and 64 × 64. No objects are baked in. The glass case has a tinted glass surface; render owned items between a back/base and a front overlay if the existing rendering system supports it.
- `runtime/catalogue/`: 16 transparent 128 × 128 item plates: the fourteen missing objects and the two replacement twins. Filenames match exact definition IDs, not invented item IDs. The left twin looks right; the right twin looks left. The same identity and artwork should be used everywhere.
- `runtime/catalogue64/`: nearest-neighbour 64 × 64 alternatives for the current catalogue pipeline. Prefer 128px sources when the view supports them.
- `sources/pack02/`, `sources/pack03/`, `sources/pack04/`: 12 original high-resolution sheets, including the five Pack 03 originals that were missing from the two copies of large.zip. These are source references only. The two annotated Pack 04 concept sheets are NOT runtime assets.
- `previews/`: real assembled/repeated tile previews and extracted catalogue/furniture, not simulated gameplay screenshots.
- `manifest.json`: dimensions, connection directions, catalogue IDs and asset metadata.
- `validation.json`: results of the pixel checks performed on this pack.

## Integration rules

Keep the existing 32 × 32 logical world grid, collision, player controls, walk cycle, NPC facings, save schema, economy and item definitions. Render the 64px technical textures at the corresponding logical tile size with nearest-neighbour filtering; choose an integer physical-pixel zoom wherever possible. Do not crop the tile textures to alpha bounds. Opaque floors are intended for full-cell placement. Wall, roof, railing, furniture and object sprites are overlays, not substitutes for a complete underlying floor texture.

Select wall/roof/rail modules by connection direction (`n/e/s/w`) and use the corresponding variant from the manifest. Do not rotate a projected front-facing tile by 90 degrees to synthesize a missing view. Door and window openings are visual; existing interaction and collision data decide whether the player can pass through. Use existing functioning furniture footprints and adapt display-anchor coordinates by previewing the actual sprites in the workshop. Do not bake any catalogue objects into a display surface.

The technical walls and floors prioritize exact connections and repeatability over the detailed appearance of the earlier standalone illustration icons. Preview and refine their shading in-game without changing the connector strips. The art pack provides the requested directional boundary tiles; if the map needs terrain corner transitions, add validated corner variants rather than stamping an incompatible straight transition.

The current repository manifest may need new category records and 128px plate support. Use the 64px fallback until the higher-resolution path is supported. Do not change the IDs, item names, descriptions, effects, price rules, or the approved Pack 02 characters. Keep Pack 03's useful loose props. Remove only superseded terrain/wall/furniture/item references, and retain SVG fallback for any catalogue object that has no faithful approved drawing.

## Pixel validation vs. game validation

The included validation checks verify file dimensions, opposite floor edges, full floor opacity, directional transition edges, matching wall/roof/rail connector edges, and presence of transparent/opaque pixels in catalogue plates. This does not establish collision correctness, atlas filtering, artistic approval, or Phaser compatibility. Run the actual game and inspect at desktop and mobile scale. Keep candidate status until approved.
