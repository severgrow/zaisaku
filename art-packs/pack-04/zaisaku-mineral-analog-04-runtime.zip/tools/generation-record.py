from PIL import Image, ImageDraw, ImageFont, ImageOps
import numpy as np, scipy.ndimage as nd
from pathlib import Path
import json, shutil, zipfile, math
root=Path('/mnt/data/ZAISAKU_Pack_04'); root.mkdir(exist_ok=True)
for sub in ['runtime/floors','runtime/transitions','runtime/architecture','runtime/furniture','runtime/catalogue','runtime/catalogue64','sources/pack04','sources/pack02','sources/pack03','previews','tools']:(root/sub).mkdir(parents=True,exist_ok=True)
records=[]
def save(im,rel,**meta):
    p=root/rel; im.save(p); records.append({'file':str(rel),'width':im.width,'height':im.height,**meta}); return im
N=64; P=63
rng=np.random.default_rng(1177)
y,x=np.mgrid[:P,:P]
def hx(s):return np.array(tuple(bytes.fromhex(s)),dtype=float)
def wrap(a):return np.pad(a,((0,1),(0,1),(0,0)),mode='wrap')
def noise(seed):
 r=np.random.default_rng(seed); n=r.integers(-3,4,(P,P)); low=nd.gaussian_filter(r.normal(size=(P,P)),1.4,mode='wrap');return n+np.round(low*10)
def brick(seed,base,rows,cols,irregular=False,metal=False):
 r=np.random.default_rng(seed); period=P; cy=rows; cx=cols
 centers=[]; ccol=[]
 for j in range(cy):
  for i in range(cx):
   centers.append(((i+.5+(.5*(j%2) if irregular else 0)+r.uniform(-.16,.16))*P/cx,(j+.5+r.uniform(-.12,.12))*P/cy)); ccol.append(r.integers(-9,10))
 ds=[]
 for u,v in centers:
  dx=np.abs((x-u+P/2)%P-P/2);dy=np.abs((y-v+P/2)%P-P/2)
  ds.append((dx**(2 if irregular else 8)+dy**(2 if irregular else 8))**(1/(2 if irregular else 8)))
 ds=np.array(ds); idx=np.argmin(ds,axis=0); sort=np.sort(ds,axis=0); diff=sort[1]-sort[0];
 col=hx(base)+np.array(ccol)[idx][...,None]+noise(seed+999)[...,None]
 # single-pixel mortar + adjacent directional highlights, without frames
 joint=diff<.75
 upper=(np.roll(joint,1,axis=0)|np.roll(joint,1,axis=1))&~joint
 lower=(np.roll(joint,-1,axis=0)|np.roll(joint,-1,axis=1))&~joint
 col[joint]-=24; col[upper]+=8; col[lower]-=7
 if metal:
  col[joint]-=4
  # subtle parallel fine brushing, not luminous hardware
  col+=((y%7==2)*3)[...,None]
 if irregular:
  moss=nd.gaussian_filter(r.random((P,P)),2,mode='wrap'); mask=(moss>.525)&(diff<3.4);col[mask]=col[mask]*.65+hx('6d7550')*.35
 return np.clip(col,0,255).astype('uint8')
def soil(seed):
 r=np.random.default_rng(seed); n=noise(seed); a=hx('8a7d6a')+n[...,None]*1.3
 for i in range(48):
  cx,cy=r.integers(0,P,2); rad=r.uniform(.7,2.8); dx=(x-cx+P/2)%P-P/2;dy=(y-cy+P/2)%P-P/2; m=dx*dx+dy*dy<rad*rad; a[m]+=r.integers(-16,13)
 return np.clip(a,0,255).astype('uint8')
def slabs(seed,base,cellx,celly,stagger=False,metal=False):
 r=np.random.default_rng(seed); row=y//celly; off=(row%3)*(cellx//3) if stagger else 0
 dx=(x+off)%cellx; dy=y%celly; ix=((x+off)%P)//cellx; vals=r.integers(-6,7,(P//celly,P//cellx)); col=hx(base)+vals[row,ix][...,None]+noise(seed)[...,None]*(.6 if metal else .8)
 joint=(dx==0)|(dy==0); highlight=(dx==1)|(dy==1); low=(dx==cellx-1)|(dy==celly-1)
 col[joint]-=21 if metal else 16;col[highlight&~joint]+=8;col[low&~joint]-=6
 if metal:col+=((y%3==1)*2)[...,None]
 return np.clip(col,0,255).astype('uint8')
base={'bone-ceramic':brick(3,'c9b59a',3,3),'mineral-paving':brick(9,'777d69',4,4,True),'industrial-metal':slabs(5,'62675d',21,21,False,True),'soil':soil(14),'resonance-path':slabs(21,'a69c83',21,21),'interior-floor':slabs(24,'998777',21,7,True)}
floors={}
for name,a in base.items():
 rgba=np.dstack([wrap(a),np.full((64,64),255,np.uint8)]); floors[name]=rgba;save(Image.fromarray(rgba),f'runtime/floors/floor-{name}.png',kind='floor',logicalTile=32,opaque=True,seamless=True)
# each directional transition has exact A/B boundary; repeated perpendicular edges match
for na,nb in [('bone-ceramic','mineral-paving'),('mineral-paving','soil')]:
 A,B=floors[na],floors[nb]
 for face in 'nesw':
  yy,xx=np.mgrid[:64,:64]; distance={'n':yy,'s':63-yy,'w':xx,'e':63-xx}[face]; tangent=xx if face in 'ns' else yy
  line=31.5+np.round(2*np.sin(tangent*2*np.pi/63)+1.3*np.sin(tangent*6*np.pi/63)); blend=np.clip((line-distance+2)/4,0,1)[...,None]
  C=np.round(A*(1-blend)+B*blend).astype(np.uint8)
  save(Image.fromarray(C),f'runtime/transitions/{na}-to-{nb}-{face}.png',kind='transition',fromMaterial=na,toMaterial=nb,neighborMaterial=nb,neighborSide=face,logicalTile=32)
# modular connected walls: 16 pixel cap width, downward face extrusion. Exact matched edge profiles using extended mask.
DIR={'n':1,'e':2,'s':4,'w':8};
def arch(mask,kind='wall',cornerstyle=None):
 yy,xx=np.mgrid[-32:96,-32:96];
 if kind=='wall': l,r,t,b,h=24,39,16,31,22
 elif kind=='roof':l,r,t,b,h=14,49,10,42,10
 else:l,r,t,b,h=27,36,25,34,14
 top=(xx>=l)&(xx<=r)&(yy>=t)&(yy<=b)
 if mask&1:top|=(xx>=l)&(xx<=r)&(yy<t)
 if mask&2:top|=(xx>r)&(yy>=t)&(yy<=b)
 if mask&4:top|=(xx>=l)&(xx<=r)&(yy>b)
 if mask&8:top|=(xx<l)&(yy>=t)&(yy<=b)
 # Rounded inner/outer bends within the cell; preserve the connector strips.
 if cornerstyle:
  rr=4 if kind=='wall' else 3; v,u=np.mgrid[-rr:rr+1,-rr:rr+1]; st=u*u+v*v<=rr*rr
  top=(nd.binary_closing(top,structure=st) if cornerstyle=='inner' else nd.binary_opening(top,structure=st))
 # distance downward from top silhouette: y-sorted upper face and extrusion
 z=np.full(top.shape,999,dtype=int);z[top]=0
 for k in range(1,h+1):
  hit=np.roll(top,k,axis=0)&(z==999);z[hit]=k
 tex=np.array([[((i*37+j*19+i*j*3)%11)//4-1 for i in range(64)] for j in range(64)])
 tex[-1]=tex[0];tex[:,-1]=tex[:,0]
 arr=np.zeros((128,128,4),np.uint8)
 active=z<=h;arr[active,3]=255
 # connected uninterrupted color strata
 pal={'wall':['e0ceb3','c9b59a','8d7b68','6d7550','4c5340','2e3328'],'roof':['a4a68b','858b71','6d7550','4c5340','8d7b68','2e3328'],'rail':['c9b59a','a89880','8d7b68','6d7550','4c5340','2e3328']}[kind]
 capedge=top&~np.roll(top,1,axis=0);capright=top&~np.roll(top,-1,axis=1);capleft=top&~np.roll(top,1,axis=1)
 arr[top,:3]=hx(pal[1]);arr[capedge|capleft,:3]=hx(pal[0]);arr[capright,:3]=hx(pal[2]);
 if kind=='wall':
  # Three ceramic cap strata with one-pixel bevels, no isolated framed panel.
  front=top&~np.roll(top,-1,axis=0)
  innerFront=top&np.roll(front,-1,axis=0)
  innerBack=top&np.roll(capedge,1,axis=0)
  innerLeft=top&np.roll(capleft,1,axis=1)
  innerRight=top&np.roll(capright,-1,axis=1)
  arr[innerBack|innerLeft,:3]=hx('d7c3a7');arr[innerRight|innerFront,:3]=hx('b3a087');arr[front,:3]=hx('8d7b68')
 for k in range(1,h+1):
  m=z==k
  if kind=='rail':
   if k in range(4,11):arr[m]=0;continue
   c=pal[1] if k<=2 else pal[4] if k>=h-1 else pal[3]
  elif kind=='roof':c=pal[2] if k<4 else pal[1] if k<h-2 else pal[4]
  else:c= '8d7b68' if k<=2 else 'e6d7c3' if k==3 else 'c9b59a' if k<13 else 'b09b80' if k<15 else '827660' if k==15 else '4c5340' if k==16 else '6d7550' if k<20 else '4c5340' if k<22 else '2e3328'
  arr[m,:3]=hx(c)
 a=arr[32:96,32:96].copy();rgb=a[:,:,:3].astype(int);rgb+=tex[:,:,None]*3; a[:,:,:3]=np.clip(rgb,0,255);a[a[:,:,3]==0,:3]=0
 return a
# derive canonical connector edge strips; match all connectors exactly.
for typ in ['wall','roof','rail']:
 hor=arch(10,typ);ver=arch(5,typ)
 def fix(a,mask):
  a=a.copy()
  for d,bit in DIR.items():
   if mask&bit:
    if d=='n':a[:4]=ver[:4]
    elif d=='s':a[-4:]=ver[-4:]
    elif d=='w':a[:,:4]=hor[:,:4]
    else:a[:,-4:]=hor[:,-4:]
  return a
 # canonical edge at connected sides, verified after generating
 if typ=='wall': masks={'straight-ew':10,'straight-ns':5,'inner-ne':3,'inner-es':6,'inner-sw':12,'inner-wn':9,'outer-ne':3,'outer-es':6,'outer-sw':12,'outer-wn':9,'t-nes':7,'t-esw':14,'t-swn':13,'t-wne':11,'cross':15,'end-n':1,'end-e':2,'end-s':4,'end-w':8}
 elif typ=='roof':masks={'straight-ew':10,'straight-ns':5,'end-n':1,'end-e':2,'end-s':4,'end-w':8,'corner-ne':3,'corner-es':6,'corner-sw':12,'corner-wn':9}
 else:masks={'straight-ew':10,'straight-ns':5,'corner-ne':3,'corner-es':6,'corner-sw':12,'corner-wn':9,'end-n':1,'end-e':2,'end-s':4,'end-w':8,'t-nes':7,'t-esw':14,'t-swn':13,'t-wne':11,'cross':15}
 for name,mask in masks.items():
  a=arch(mask,typ,('inner' if name.startswith('inner') else 'outer' if name.startswith('outer') or name.startswith('corner') else None)); im=Image.fromarray(a);d=ImageDraw.Draw(im)
  if typ=='wall' and name.startswith('outer'):
   # Convex bend uses rounded opening; inner bend uses a concave fillet.
   pass
  if typ=='roof' and 'straight-ew'==name:
   for i in [16,32,48]: d.line((i,12,i,37),fill='#6d7550',width=1);d.line((i+1,12,i+1,37),fill='#a0a38a',width=1)
  if typ=='rail':
   d.rounded_rectangle((27,24,36,52),radius=2,fill='#4c5340');d.rectangle((28,25,35,28),fill='#c9b59a');d.rectangle((28,31,30,48),fill='#8d7b68');d.rectangle((28,50,35,52),fill='#6d7550')
  im=Image.fromarray(fix(np.array(im),mask));save(im,f'runtime/architecture/{typ}-{name}.png',kind=typ,connections=''.join(k for k,v in DIR.items() if mask&v),logicalTile=32,anchor=[32,64])
 if typ=='wall':
  for name in ['door-frame-open','window-open']:
   im=Image.fromarray(hor.copy());d=ImageDraw.Draw(im)
   # shape cutout with an unfilled opening: transparent below the arch or through window
   if name.startswith('door'):
    d.rounded_rectangle((16,23,47,55),radius=7,fill='#8d7b68');d.rounded_rectangle((19,25,44,58),radius=6,fill='#4c5340');d.rounded_rectangle((22,28,41,62),radius=5,fill=(0,0,0,0));d.rectangle((22,36,41,63),fill=(0,0,0,0));d.rectangle((17,39,18,45),fill='#a87428')
   else:
    d.rounded_rectangle((13,25,50,44),radius=6,fill='#8d7b68');d.rounded_rectangle((15,26,48,43),radius=5,fill='#4c5340');d.rounded_rectangle((18,29,45,40),radius=3,fill=(0,0,0,0));d.line((19,27,44,27),fill='#d29a3a',width=1)
   save(im,f'runtime/architecture/{name}.png',kind='wall',connections='ew',logicalTile=32,emptyOpening=True,anchor=[32,64])
# catalogue source extraction: binary alpha core, remove disconnected fringe specks, nearest-neighbor sampling
src=Path('/mnt/data/a_clean_transparent_background_sprite_sheet_of_16.png'); srcim=Image.open(src).convert('RGBA');
def extract(im, rect, min_alpha=155, largest=False):
 a=np.array(im.crop(rect).convert('RGBA')); mask=a[:,:,3]>=min_alpha
 lab,n=nd.label(mask); counts=np.bincount(lab.ravel()); counts[0]=0
 if counts.size>1:
  keep=counts>=max(12,int(counts.max()*.012));keep[0]=False
  if largest:keep=np.arange(len(counts))==counts.argmax()
  mask=keep[lab]
 a[:,:,3]=np.where(mask,255,0); a[~mask,:3]=0
 out=Image.fromarray(a); bb=out.getbbox();return out.crop(bb) if bb else out

def fit(im,size,pad=5):
 scale=min((size[0]-2*pad)/im.width,(size[1]-2*pad)/im.height)
 im=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.NEAREST);out=Image.new('RGBA',size);out.alpha_composite(im,((size[0]-im.width)//2,(size[1]-im.height)//2));return out
ids=['bone-dice','spare-key','late-bell','second-mouth','station-pendulum','green-filter','eclipse-monocle','prism-ticket','paper-charm','counterfeit-seal','travellers-weight','cracked-saucer','blue-fault','closed-city','twin-left','twin-right']
W,H=srcim.size
for i,id in enumerate(ids):
 col,row=i%4,i//4; rect=(round(col*W/4),round(row*H/4),round((col+1)*W/4),round((row+1)*H/4)); im=extract(srcim,rect)
 im=fit(im,(128,128),6)
 # key generated with a conventional bit: remove ward and preserve the rounded stem with pixel-precise clipping.
 if id=='spare-key':
  a=np.array(im); yy,xx=np.mgrid[:128,:128]; # tip in lower left, bit protrudes below/right of diagonal stem
  cut=(yy>69)&(xx<76)&(xx+yy>126)
  a[cut]=0;im=Image.fromarray(a)
 save(im,f'runtime/catalogue/item-{id}.png',kind='catalogue',definitionId=id,pixelKey=f'item-{id}',status='candidate')
 save(im.resize((64,64),Image.Resampling.NEAREST),f'runtime/catalogue64/item-{id}.png',kind='catalogue-fallback',definitionId=id,status='candidate')
# Empty furniture from generated isolated illustrations (no baked collection objects)
fursrc=Image.open('/mnt/data/a_detailed_pixel_art_asset_sheet_on_a_transparent.png').convert('RGBA')
for id,rect in [('display-shelf',(10,548,167,737)),('glass-display',(180,555,317,735)),('display-pedestal',(340,599,455,733))]:
 im=extract(fursrc,rect,165,largest=True);im=fit(im,(128,128),4)
 save(im,f'runtime/furniture/furniture-{id}.png',kind='furniture',status='candidate',logicalFootprint=[1,1],anchor=[64,128],empty=True)
 save(im.resize((64,64),Image.Resampling.NEAREST),f'runtime/furniture/furniture-{id}-64.png',kind='furniture-fallback',empty=True,anchor=[32,64])
# exact source sheets, not loose cropped large.zip folder
for p in Path('/mnt/data/zaisaku_art02/sources').glob('*.png'):shutil.copy2(p,root/'sources/pack02'/p.name)
for p in Path('/mnt/data/zaisaku_art03/sources').glob('*.png'):shutil.copy2(p,root/'sources/pack03'/p.name)
for p in [src,Path('/mnt/data/a_detailed_pixel_art_sprite_sheet_image_in_a_clean.png'),Path('/mnt/data/a_detailed_pixel_art_asset_sheet_on_a_transparent.png')]:shutil.copy2(p,root/'sources/pack04'/p.name)
# QA: precise edge matching
checks=[]
def check(label,ok):checks.append({'check':label,'pass':bool(ok)})
for n,a in floors.items():check(n+' full opacity',np.all(a[:,:,3]==255));check(n+' opposite x edges',np.array_equal(a[:,0],a[:,-1]));check(n+' opposite y edges',np.array_equal(a[0],a[-1]))
for r in records:
 p=root/r['file'];a=np.array(Image.open(p));check(r['file']+' dimensions',a.shape[:2]==(r['height'],r['width']))
 if r['kind']=='transition':
  A=floors[r['fromMaterial']];B=floors[r['toMaterial']];d=r['neighborSide'];
  edges={'n':(a[0],B[-1],a[-1],A[0],a[:,0],a[:,-1]),'s':(a[-1],B[0],a[0],A[-1],a[:,0],a[:,-1]),'e':(a[:,-1],B[:,0],a[:,0],A[:,-1],a[0],a[-1]),'w':(a[:,0],B[:,-1],a[:,-1],A[:,0],a[0],a[-1])}[d];check(r['file']+' exact material edges',np.array_equal(edges[0],edges[1]) and np.array_equal(edges[2],edges[3]) and np.array_equal(edges[4],edges[5]) and np.all(a[:,:,3]==255))
 if r['kind'] in ['wall','roof','rail']:
  typ=r['kind']; Hh=np.array(Image.open(root/f'runtime/architecture/{typ}-straight-ew.png'));Vv=np.array(Image.open(root/f'runtime/architecture/{typ}-straight-ns.png'))
  ed={'n':(a[0],Vv[-1]),'s':(a[-1],Vv[0]),'e':(a[:,-1],Hh[:,0]),'w':(a[:,0],Hh[:,-1])};check(r['file']+' exact connected edges',all(np.array_equal(*ed[d]) for d in r['connections']))
  # non-connected edge is transparent unless another projected face touches it (geometry should not)
 if r['kind']=='catalogue':check(r['file']+' nonempty alpha',np.any(a[:,:,3]==255) and np.any(a[:,:,3]==0))
# QA previews: 3x3 repeated floors, transitions three lanes, actual connected building run
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
def page(title,tiles,cols=3,cell=(232,240),repeat=False):
 rows=math.ceil(len(tiles)/cols);out=Image.new('RGB',(cols*cell[0],rows*cell[1]+48),'#252b28');d=ImageDraw.Draw(out);d.text((16,12),title,font=font,fill='#e6d7c3')
 for i,(name,im) in enumerate(tiles):
  ox=i%cols*cell[0]+8;oy=i//cols*cell[1]+48
  if repeat:
   for j in range(3):
    for k in range(3):out.paste(im,(ox+k*64,oy+j*64),im if im.mode=='RGBA' else None)
  else:
   im=im.copy(); sz=min(cell[0]-16,cell[1]-44); im.thumbnail((sz,sz),Image.Resampling.NEAREST);out.paste(im,(ox+(cell[0]-16-im.width)//2,oy+(cell[1]-44-im.height)//2),im if im.mode=='RGBA' else None)
  d.text((ox,oy+cell[1]-35),name,font=font,fill='#d6c8b3')
 return out
page('SEAM TEST / 3 x 3 repetitions',[(n,Image.fromarray(a)) for n,a in floors.items()],repeat=True).save(root/'previews/floor-seam-test.png')
cat=[(id,Image.open(root/f'runtime/catalogue/item-{id}.png')) for id in ids]
page('CATALOGUE / 128px candidates',cat,cols=4,cell=(220,185)).save(root/'previews/catalogue.png')
archs=[(Path(r['file']).stem,Image.open(root/r['file'])) for r in records if r['kind'] in ['wall','roof','rail']]
page('CONNECTED ARCHITECTURE / individual components',archs,cols=5,cell=(200,120)).save(root/'previews/architecture.png')
# assemble horizontal facades and a rectangular connection sample, plus the floor transitions
im=Image.new('RGBA',(640,480),'#252b28');
for yy in range(64,448,64):
 for xx in range(0,640,64):im.alpha_composite(Image.fromarray(floors['bone-ceramic']),(xx,yy))
for j in range(1,9):
 key='wall-straight-ew' if j not in [3,6] else ('window-open' if j==3 else 'door-frame-open'); im.alpha_composite(Image.open(root/f'runtime/architecture/{key}.png'),(j*64,64))
for j,key in enumerate(['wall-outer-es','wall-straight-ew','wall-straight-ew','wall-outer-sw']):im.alpha_composite(Image.open(root/f'runtime/architecture/{key}.png'),((j+2)*64,192))
for j,key in enumerate(['wall-straight-ns','wall-straight-ns']):
 for col in (2,5):im.alpha_composite(Image.open(root/f'runtime/architecture/{key}.png'),(col*64,(j+4)*64))
for j,key in enumerate(['wall-outer-ne','wall-straight-ew','wall-straight-ew','wall-outer-wn']):im.alpha_composite(Image.open(root/f'runtime/architecture/{key}.png'),((j+2)*64,384))
for j,key in enumerate(['rail-end-e','rail-straight-ew','rail-straight-ew','rail-end-w']):im.alpha_composite(Image.open(root/f'runtime/architecture/{key}.png'),((j+6)*64,320))
ImageDraw.Draw(im).text((16,16),'CONNECTED WALL / doorway and window / actual tile assembly',font=font,fill='#e6d7c3');im.convert('RGB').save(root/'previews/assembled-walls.png')
trans=[]
for r in records:
 if r['kind']=='transition':
  a=Image.open(root/r['file']); A=Image.fromarray(floors[r['fromMaterial']]);B=Image.fromarray(floors[r['toMaterial']]);d=r['neighborSide'];
  arr=Image.new('RGBA',(192,192));
  for j in range(3):
   for k in range(3):
    q=j if d in 'ns' else k; seq=[B,a,A] if d in 'nw' else [A,a,B];arr.alpha_composite(seq[q],(64*k,64*j))
  trans.append((f"{r['fromMaterial']} / {r['neighborSide']}",arr))
page('TRANSITIONS / actual 3 x 3 placement',trans,cols=4,cell=(232,240)).save(root/'previews/transitions.png')
fur=[(p.stem,Image.open(p)) for p in (root/'runtime/furniture').glob('*.png') if not p.stem.endswith('-64')]
page('EMPTY DISPLAY FURNITURE',fur,cols=3,cell=(245,185)).save(root/'previews/furniture.png')
# store only validation claims established by pixel tests
(root/'manifest.json').write_text(json.dumps({'pack':'Mineral Analog 04','status':'candidate','logicalTileSize':32,'textureFilter':'nearest','runtimeAssets':records,'notes':['Use source files as references, not as runtime art.','Art generated for catalogue and display furniture; technical terrain and connected architecture drawn at native resolution.','Wall inner/outer variants have concave and convex rounded bends, respectively; connector profiles are identical.','Twin left means the figure positioned at the left, facing right.']},indent=2))
(root/'validation.json').write_text(json.dumps({'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'checks':checks},indent=2))
print('records',len(records),'passed',sum(c['pass'] for c in checks),'failed',[(c['check']) for c in checks if not c['pass']]);print('sources',len(list((root/'sources').rglob('*.png'))))
